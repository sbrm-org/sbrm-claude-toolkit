# humanizer

Adapted from the open-source humanizer skill by blader (https://github.com/blader/humanizer), with substantial local modifications.
